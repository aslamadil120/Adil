// navbar toggle
navToggleBtn.addEventListener("click", () => {
  let menu = document.querySelector("nav")
  menu.classList.toggle("responsive");
});


// navbar 
const sections = document.querySelectorAll("section");
const navLinks = document.querySelectorAll("nav>ul>li>a");

onscroll = () => {
  sections.forEach((sec) => {
    let top = window.scrollY;
    let offset = sec.offsetTop - 150;
    let height = sec.offsetHeight;
    
    if (top >= offset && top < offset + height) {
      
      navLinks.forEach((link) => {
        let activeLink = document.querySelector(`nav ul li a[href="#${sec.id}"]`);
        
        link.classList.remove("active");
        activeLink.classList.add("active");
      });
    }
  });
};


// toggle theme

theme_toggle.addEventListener("click", () => {
  const body = document.querySelector("body");

  body.classList.toggle("dark");
  
  theme_toggle.classList.toggle("dark");
  
  
  if (theme_toggle.innerText === "dark") {
    theme_toggle.innerText = "light"
  } else {
    theme_toggle.innerText = "dark"
  }
});


//typed animation
let text = document.querySelector('#text');
  
const changeText = () => {
  setTimeout(() => {
     text.innerText = "Grapic Designer";
  }, 0)
  setTimeout(() => {
     text.innerText = "Web Designer";
  }, 4000);
  setTimeout(() => {
     text.innerText = "Web Developer";
  }, 8000);
  setTimeout(() => {
     text.innerText = "freelancer";
  }, 12000);
}
  
changeText();
setInterval(changeText, 16000);
